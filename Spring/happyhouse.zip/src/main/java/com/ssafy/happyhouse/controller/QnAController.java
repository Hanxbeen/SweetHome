package com.ssafy.happyhouse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.dto.Question;
import com.ssafy.happyhouse.model.service.QuestionService;

@RestController
@RequestMapping("/qna")
@CrossOrigin("*")
public class QnAController {
	@Autowired
	QuestionService qservice;
	
	@GetMapping("/q/{noq}")
	public Question getQuestion(@PathVariable int noq) {
		return qservice.select(noq);
	}
	
	@GetMapping("/q")
	public List<Question> getAllQuestion(){
		return qservice.selectAll();
	}
	
	@PostMapping("/q")
	public int registQuestion(@RequestBody Question question) {
		return qservice.insert(question);
	}
	
	@PutMapping("/q")
	public int updateQuestion(@RequestBody Question question) {
		return qservice.update(question);
	}
	
	@DeleteMapping("/q/{noq}")
	public int deleteQuestion(@PathVariable int noq) {
		return qservice.delete(noq);
	}
	
}
